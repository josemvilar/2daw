window.onload=function(){
    window.alert("Esto es una alerta");
}