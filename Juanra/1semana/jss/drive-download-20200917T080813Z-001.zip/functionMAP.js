function power2(x){
    return x**2;
}
let array = [1,2,3,4,5];
let newArray = array.map(power2);
console.log(newArray);