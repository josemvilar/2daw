window.onload=function(){
    console.log("HELLO WORLD");
    
    let i = 43;
    for(let i=0; i<10; i++) {
        console.log(i);
    }
    console.log(i);
}