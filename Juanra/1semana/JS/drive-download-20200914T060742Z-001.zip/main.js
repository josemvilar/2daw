
window.onload=function(){
    console.log("Hello World");

        // let resp_confirm=window.confirm("Do you want to pass?");
        // console.log(resp_confirm);
        // if (resp_confirm==true){
        //     window.alert("Good Luck");
        // }

        // "Te pregunte el nombre, si es cliente te diga TheBest, si no no"
        
        var txt;
        var person = prompt("Please enter your name:", "");
        if (person == "Client") {
            window.alert("The best");

        } else {
            window.alert("Not the best");
        }
}
