window.onload=function () {


    //Mensaje en consola:    console.log("Hello World");
    // Para una alerta:     alert("Yeee");
    // confirmar:       window.confirm("");

    window.confirm("Te gustan las frutas?");

    if (confirm) {
        window.alert("Te gustan las frutas");
    }else {
        window.alert("No te gustan las frutas");

    }


}